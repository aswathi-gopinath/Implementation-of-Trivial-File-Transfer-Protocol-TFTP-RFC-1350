#include "tftp.h"
#include "tftp_client.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <ctype.h>

int connect_flag = 0;
char mode[10] = "default";  // default mode

int main() 
{
    tftp_client_t client;
    memset(&client, 0, sizeof(client));
    while(1)
    {
        int option;
        printf("Menu\n1.Connect\n2.put\n3.get\n4.mode\n5.exit\n");
        scanf("%d", &option);
        switch(option)
        {
            case 1: 
                connect_flag = 1;
                connect_to_server(&client);
                break;
            case 2: 
                put_file(&client);
                break;
            case 3:
                get_file(&client);
                break;
            case 4:
                select_mode();
                break;
            case 5:
                printf("Exiting...\n");
                return 0;
        }
    }
}

// connecting client and server
int connect_to_server(tftp_client_t *client) 
{
    char ip[16];
    printf("Enter the server IP: ");
    scanf("%s", ip);
    int count = 0;
    for(int i = 0; ip[i]; i++) 
    {
        if(!(isdigit(ip[i]) || ip[i] == '.')) 
        {
            printf("Invalid IP\n"); return 0;
        }
        if(ip[i] == '.') 
            count++;
        if(ip[i] == '.' && ip[i+1] == '.') 
        { 
            printf("Invalid IP\n"); 
            return 0; 
        }
    }
    if(count != 3) 
    { 
        printf("Invalid IP\n");
        return 0; 
    }
    strcpy(client->server_ip, ip);
    client->sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(client->sockfd < 0) 
    {
        perror("ERROR : "); 
        return 0; 
    }
    client->server_addr.sin_family = AF_INET;
    client->server_addr.sin_port = htons(PORT);
    client->server_addr.sin_addr.s_addr = inet_addr(client->server_ip);
    client->server_len = sizeof(client->server_addr);
    printf("Connected to server %s\n", client->server_ip);
}

// Send WRQ request and file to server
int put_file(tftp_client_t *client)
{
    if(connect_flag == 0) 
    {
        printf("Server not connected\n"); 
        return 0; 
    }
    char filename[100];
    printf("Enter filename: ");
    scanf("%s", filename);

    int fd = open(filename, O_RDONLY);
    if(fd == -1) 
    {
        perror("Error "); 
        return 0; 
    }
    tftp_packet packet;
    memset(&packet, 0, sizeof(packet));
    send_request(client->sockfd, client->server_addr, filename, WRQ);

    socklen_t server_len = client->server_len;
    recvfrom(client->sockfd, &packet, sizeof(packet), 0, (struct sockaddr *)&client->server_addr, &server_len);

    if(ntohs(packet.body.ack_packet.block_number) == 0)
    {
        printf("Server cannot open file\n"); 
        close(fd);
        return 0;
    }
    int packet_no = 1;
    int total_bytes_sent = 0;

    while(1) 
    {
        memset(&packet, 0, sizeof(packet));
        int bytes_read = 0;

        if(strcmp(mode, "octet") == 0) 
        {
            bytes_read = read(fd, packet.body.data_packet.data, 1);
        } 
        else if(strcmp(mode, "netascii") == 0) 
        {
            char buffer[512];
            int n = read(fd, buffer, 512);
            int k = 0;
            for(int i = 0; i < n; i++)
            {
                if(buffer[i] == '\n') 
                {
                    packet.body.data_packet.data[k++] = '\r';
                }
                packet.body.data_packet.data[k++] = buffer[i];
            }
            bytes_read = k;
        } 
        else 
        { 
            // default
            bytes_read = read(fd, packet.body.data_packet.data, 512);
        }
        packet.opcode = htons(DATA);
        packet.body.data_packet.block_number = htons(packet_no);

        while(1)
        {
            sendto(client->sockfd, &packet, bytes_read + 4, 0, (struct sockaddr *)&client->server_addr, client->server_len);
            recvfrom(client->sockfd, &packet, sizeof(packet), 0, (struct sockaddr *)&client->server_addr, &server_len);
            int ack = ntohs(packet.body.ack_packet.block_number);
            if(ack == 1) 
            {
                printf("Block %d sent, bytes in this block = %d\n", packet_no, bytes_read);
                total_bytes_sent = total_bytes_sent + bytes_read;
                break;
            } 
            else if(ack == 0)
            {
                printf("Server reported error\n");
                close(fd);
                return 0;
            }
        }

        // EOF check
        if(strcmp(mode, "octet") == 0) 
        {
            if(bytes_read < 1) 
                break;
        } 
        else 
        {
            if(bytes_read < 512) 
                break;
        }
        packet_no++;
    }
    close(fd);
    printf("File transfer complete, total bytes sent = %d\n", total_bytes_sent);
    return 1;
}


void get_file(tftp_client_t *client)
{
    if(connect_flag == 0) 
    { 
        printf("Client and server not connected\n"); 
        return; 
    }
    char filename[100];
    printf("Enter filename: ");
    scanf("%s", filename);

    tftp_packet packet;
    memset(&packet, 0, sizeof(packet));
    send_request(client->sockfd, client->server_addr, filename, RRQ);

    socklen_t server_len = client->server_len;
    recvfrom(client->sockfd, &packet, sizeof(packet), 0, (struct sockaddr *)&client->server_addr, &server_len);

    if(ntohs(packet.body.ack_packet.block_number) == 0) 
    {
        printf("Server cannot open file\n"); 
        return; 
    }
    int fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, 0666);
    if(fd == -1) 
    {
        perror("Error opening file for write"); 
        return; 
    }

    int packet_no = 1;
    int total_bytes_received = 0;

    while(1) 
    {
        memset(&packet, 0, sizeof(packet));
        int bytes = recvfrom(client->sockfd, &packet, sizeof(packet), 0, (struct sockaddr *)&client->server_addr, &server_len);
        if(bytes <= 0) 
            break;
        int data_bytes = bytes - 4;
        if(strcmp(mode, "netascii") == 0) 
        {
            for(int i = 0; i < data_bytes; i++) 
            {
                if(packet.body.data_packet.data[i] == '\r' && packet.body.data_packet.data[i+1] == '\n') 
                {
                    char c = '\n';
                    write(fd, &c, 1);
                    i++;
                    total_bytes_received++;
                } 
                else 
                {
                    write(fd, &packet.body.data_packet.data[i], 1);
                    total_bytes_received++;
                }
            }
        } 
        else 
        {
            write(fd, packet.body.data_packet.data, data_bytes);
            total_bytes_received += data_bytes;
        }

        packet.opcode = htons(ACK);
        packet.body.ack_packet.block_number = htons(1);
        sendto(client->sockfd, &packet, 4, 0, (struct sockaddr *)&client->server_addr, server_len);

        printf("Block %d received, bytes in this block = %d, total bytes received = %d\n", packet_no, data_bytes, total_bytes_received);

        // EOF check
        if(strcmp(mode, "octet") == 0) 
        {
            if(data_bytes < 1) 
                break;
        } 
        else 
        {
            if(data_bytes < 512) 
                break;
        }
        packet_no++;
    }
    close(fd);
    printf("File receive complete, total bytes received = %d\n", total_bytes_received);
}

void send_request(int sockfd,struct sockaddr_in server_addr, char *filename, int opcode)
{
    tftp_packet packet;
    memset(&packet, 0, sizeof(packet));
    packet.opcode = htons(opcode);
    strcpy(packet.body.request.filename, filename);
    strcpy(packet.body.request.mode, mode);
    //send to server
    sendto(sockfd, &packet, sizeof(packet), 0, (struct sockaddr*)&server_addr, sizeof(server_addr));
}

// Select transfer mode
void select_mode()
{
    int choice;
    printf("Select mode:\n1. default\n2. octet\n3. netascii\n");
    scanf("%d", &choice);
    switch(choice) 
    {
        case 1: strcpy(mode, "default"); 
                break;
        case 2: strcpy(mode, "octet"); 
                break;
        case 3: strcpy(mode, "netascii"); 
                break;
        default:
            printf("Invalid choice\n");
            return;
    }
    printf("Mode selected: %s\n", mode);
}