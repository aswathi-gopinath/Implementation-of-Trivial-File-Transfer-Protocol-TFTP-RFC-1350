#include "tftp.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>

void handle_client(int sockfd, struct sockaddr_in client_addr, socklen_t client_len, tftp_packet *packet);

int main() 
{
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len;
    tftp_packet packet;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sockfd < 0) 
    {
        printf("Socket creation failed");
        return 0;
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if(bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) 
    {
        printf("Bind failed");
        close(sockfd);
        return 0;
    }
    printf("TFTP Server listening on port %d...\n", PORT);
    while(1) 
    {
        client_len = sizeof(client_addr);
        printf("Waiting for the file and operation\n");
        int n = recvfrom(sockfd, &packet, sizeof(tftp_packet), 0, (struct sockaddr *)&client_addr, &client_len);
        if(n < 0) 
        {
            printf("Receive failed");
            continue;
        }
        handle_client(sockfd, client_addr, client_len, &packet);
    }
    close(sockfd);
    return 0;
}

void handle_client(int sockfd, struct sockaddr_in client_addr, socklen_t client_len, tftp_packet *packet) 
{
    int opcode = ntohs(packet->opcode);
    if(opcode == RRQ) 
    {
        printf("RRQ received for file: %s\n", packet->body.request.filename);
        send_file(sockfd, client_addr, client_len, packet);
    }
    else if(opcode == WRQ) 
    {
        printf("WRQ received for file: %s\n", packet->body.request.filename);
        receive_file(sockfd, client_addr, client_len, packet);
    }
    else 
    {
        printf("Invalid request\n");
    }
}
