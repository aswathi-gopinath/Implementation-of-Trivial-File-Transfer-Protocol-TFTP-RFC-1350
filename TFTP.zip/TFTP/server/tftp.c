
/* Common file for server & client */

#include "tftp.h"
void send_file(int sockfd, struct sockaddr_in client_addr, socklen_t client_len, tftp_packet *packet) 
{
    char filename[100];
    strcpy(filename, packet->body.request.filename);

    int fd = open(filename, O_RDONLY);
    if(fd == -1) 
    {
        perror("Error ");
        packet->opcode = htons(ACK);
        packet->body.ack_packet.block_number = htons(0);
        sendto(sockfd, packet, 4, 0, (struct sockaddr *)&client_addr, client_len);
        return;
    }
    packet->opcode = htons(ACK);
    packet->body.ack_packet.block_number = htons(1); // ready
    sendto(sockfd, packet, 4, 0, (struct sockaddr *)&client_addr, client_len);
    int packet_no = 1;
    int total_bytes_sent = 0;
    while(1) 
    {
        tftp_packet data_packet;
        memset(&data_packet, 0, sizeof(data_packet));
        data_packet.opcode = htons(DATA);
        int read_bytes = 0;
        if(strcmp(packet->body.request.mode, "octet") == 0) 
        {
            read_bytes = read(fd, data_packet.body.data_packet.data, 1); // 1 byte per packet for octet mode
        } 
        else if(strcmp(packet->body.request.mode, "netascii") == 0) 
        {
            char ch;
            while(read(fd, &ch, 1) == 1 && read_bytes < 512) 
            {
                if(ch == '\n') 
                {
                    data_packet.body.data_packet.data[read_bytes++] = '\r';
                }
                data_packet.body.data_packet.data[read_bytes++] = ch;
            }
        } 
        else 
        { // default mode
            read_bytes = read(fd, data_packet.body.data_packet.data, 512);
        }
        sendto(sockfd, &data_packet, read_bytes + 4, 0, (struct sockaddr *)&client_addr, client_len);
        recvfrom(sockfd, packet, sizeof(tftp_packet), 0, (struct sockaddr *)&client_addr, &client_len);
        if(ntohs(packet->body.ack_packet.block_number) != 1) 
        {
            printf("Client error\n");
            break;
        }
        total_bytes_sent = total_bytes_sent +  read_bytes;
        printf("Block %d sent, bytes in this block = %d, total bytes sent = %d\n", packet_no, read_bytes, total_bytes_sent);
        //EOF or not
        if(strcmp(packet->body.request.mode, "octet") == 0) 
        {
            if(read_bytes < 1)
                 break;
        }
        else 
        {
            if(read_bytes < 512) 
                break;
        }
        packet_no++;
    }
    close(fd);
    printf("File transfer complete, total bytes sent = %d\n", total_bytes_sent);
}


void receive_file(int sockfd, struct sockaddr_in client_addr, socklen_t client_len, tftp_packet *packet) 
{
    char filename[100];
    strcpy(filename, packet->body.request.filename);
    int fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, 0666);

    packet->opcode = htons(ACK);
    packet->body.ack_packet.block_number = htons(1);
    sendto(sockfd, packet, 4, 0, (struct sockaddr *)&client_addr, client_len);

    int total_bytes_received = 0;
    int packet_no = 1;

    while(1) 
    {
        tftp_packet recv_packet;
        socklen_t len = client_len;
        int bytes = recvfrom(sockfd, &recv_packet, sizeof(recv_packet), 0, (struct sockaddr *)&client_addr, &len);
        if(bytes <= 0) 
            break;
        int data_bytes = bytes - 4;
        if(strcmp(packet->body.request.mode, "netascii") == 0) 
        {
            for(int i = 0; i < data_bytes; i++) 
            {
                if(recv_packet.body.data_packet.data[i] == '\r' && recv_packet.body.data_packet.data[i+1] == '\n') 
                {
                    char c = '\n';
                    write(fd, &c, 1);
                    i++;
                    total_bytes_received++;
                } 
                else 
                {
                    write(fd, &recv_packet.body.data_packet.data[i], 1);
                    total_bytes_received++;
                }
            }
        } 
        else 
        {
            write(fd, recv_packet.body.data_packet.data, data_bytes);
            total_bytes_received += data_bytes;
        }
        recv_packet.opcode = htons(ACK);
        recv_packet.body.ack_packet.block_number = htons(1);
        sendto(sockfd, &recv_packet, 4, 0, (struct sockaddr *)&client_addr, client_len);
        printf("Block %d received, bytes in this block = %d, total bytes received = %d\n", packet_no, data_bytes, total_bytes_received);
        // EOF or not
        if(strcmp(packet->body.request.mode, "octet") == 0) 
        {
            if(data_bytes < 1) 
                break;
        } 
        else 
        {
            if(data_bytes < 512)
                 break;
        }
        packet_no++;
    }
    close(fd);
    printf("File receive complete, total bytes received = %d\n", total_bytes_received);
}

